#ifndef SOFTCLIPPEDREAD_H
#define SOFTCLIPPEDREAD_H

class ISoftClippedRead
{
public:
    virtual ~ISoftClippedRead() {}
    GenomePosition GetClippingPosition() {}
    virtual IVariant* FindCall() = 0;
};

#endif // SOFTCLIPPEDREAD_H
