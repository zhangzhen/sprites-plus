#ifndef DELETIONCALLER_H
#define DELETIONCALLER_H

#include "variantcaller.h"

class DeletionCaller : public IVariantCaller
{
public:
    DeletionCaller(ISoftClippedRead *pRead);
    IVariant *FindCall();
};

#endif // DELETIONCALLER_H
