#ifndef TARGETREGIONFINDER_H
#define TARGETREGIONFINDER_H

#include "ChromosomeRegion.h"
#include "SpanningPair.h"
#include "spanningpairsreader.h"
#include "bipartitioner.h"
#include "bipartitionqualifier.h"
#include "positionpicker.h"

class ITargetRegionFinder
{
public:
    ITargetRegionFinder(ISpanningPairsReader* pPairsReader,
                        IBiPartitioner* pPartitioner,
                        IBiPartitionQualifier* pQualifier,
                        IPositionPicker* pPosPicker);
    virtual ~ITargetRegionFinder() {}
    ChromosomeRegion* FindRegion();

protected:
    virtual ChromosomeRegion* GetFinalRegion() = 0;

protected:
    std::vector<SpanningPair*> pairs;
    ISpanningPairsReader* pPairsReader;
    IBiPartitioner* pPartitioner;
    IBiPartitionQualifier* pQualifier;
    IPositionPicker* pPosPicker;
};

#endif // TARGETREGIONFINDER_H
