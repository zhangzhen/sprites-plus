#include "DeletionCaller.h"

DeletionCaller::DeletionCaller(ISoftClippedRead *pRead)
    : IVariantCaller(pRead)
{
}


IVariant *DeletionCaller::FindCall()
{
    ChromosomeRegion chromoReg = pTargetRegionFinder->FindRegion(positions);
    string targetSeq = pSeqFetcher->Fetch(chromoReg);
    AlignmentResults alignmentResults = pSeqAligner->Align(targetSeq, pRead->GetSequence());
    return pRead->FindCall(alignmentResults);
}
