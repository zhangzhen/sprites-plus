#include "AnovaBiPartitionQualifier.h"

AnovaBiPartitionQualifier::AnovaBiPartitionQualifier()
{
}

bool AnovaBiPartitionQualifier::IsQualified(const std::vector<int> &insertSizes, const std::vector<int> &labels)
{
}
