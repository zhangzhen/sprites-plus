#ifndef PERCHROMDELELETIONCALLER_H
#define PERCHROMDELELETIONCALLER_H

#include "softclippedread.h"
#include "api/BamReader.h"

class PerChromDeleletionCaller
{
public:
    PerChromDeleletionCaller();
    void AddRead(ISoftClippedRead *pRead);
    bool Call(std::vector<IVariant*> &variants);

private:
    std::map<int, SoftClippedReadCluster*> clusterMap;
};

#endif // PERCHROMDELELETIONCALLER_H
