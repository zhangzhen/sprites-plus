#ifndef TARGETREGIONTOLEFTFINDER_H
#define TARGETREGIONTOLEFTFINDER_H

#include "targetregionfinder.h"

class TargetRegionToLeftFinder : public ITargetRegionFinder
{
public:
    TargetRegionToLeftFinder();

protected:
    ChromosomeRegion *GetFinalRegion();
};

#endif // TARGETREGIONTOLEFTFINDER_H
