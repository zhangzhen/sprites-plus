#include "Reference.h"

Reference::Reference(int id, std::string &name)
    : id(id),
      name(name)
{
}
