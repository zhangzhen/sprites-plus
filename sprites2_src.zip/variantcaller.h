#ifndef VARIANTCALLER_H
#define VARIANTCALLER_H

#include "softclippedread.h"
#include "GenomePosition.h"
#include <vector>

class IVariantCaller
{
public:
    IVariantCaller(ISoftClippedRead *pRead);
    void AddRead(ISoftClippedRead *pRead);
    GenomePosition GetClippingPosition() { return pReads[0]->GetClippingPosition(); }
    virtual ~IVariantCaller() {}
    virtual IVariant* FindCall() = 0;

private:
    std::vector<ISoftClippedRead *> pReads;
};

#endif // VARIANTCALLER_H
